const { VK } = require('vk-io');
let config = require("../config.json");
const vk = new VK({ token: config.group_token });

exports.execute = async (message, vkcoin) => {
  let url = vkcoin.getLink(1000, false)

  let short = (await vk.api.utils.getShortLink({ url })).short_url;

  message.send(`
  💰 Чтобы пополнить баланс, отправьте VK Coin по этой ссылке ${short}`)
}

exports.info = {
  name: [
    "пополнить"
  ],
  access: false
}
